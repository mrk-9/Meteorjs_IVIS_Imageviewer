Template.aboutModal.helpers({
    githubUrl() {
        return 'https://github.com/OHIF/Viewers';
    }
});
