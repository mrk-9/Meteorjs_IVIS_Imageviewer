import { Studybase } from '../namespace';

/**
 * Imports file with side effects only (files that do not export anything...)
 */

import './collections';
import './lib/debugReactivity';

/**
 * Exported Functions
 */

// getElementIfNotEmpty
import { getElementIfNotEmpty } from './lib/getElementIfNotEmpty';
Studybase.getElementIfNotEmpty = getElementIfNotEmpty;

// getStackDataIfNotEmpty
import { getStackDataIfNotEmpty } from './lib/getStackDataIfNotEmpty';
Studybase.getStackDataIfNotEmpty = getStackDataIfNotEmpty;

// switchToImageRelative
import { switchToImageRelative } from './lib/switchToImageRelative';
Studybase.switchToImageRelative = switchToImageRelative;

// switchToImageByIndex
import { switchToImageByIndex } from './lib/switchToImageByIndex';
Studybase.switchToImageByIndex = switchToImageByIndex;

// getFrameOfReferenceUID
import { getFrameOfReferenceUID } from './lib/getFrameOfReferenceUID';
Studybase.getFrameOfReferenceUID = getFrameOfReferenceUID;

// getImageIdForImagePath
import { getImageIdForImagePath } from './lib/getImageIdForImagePath';
Studybase.getImageIdForImagePath = getImageIdForImagePath;

// updateCrosshairsSynchronizer
import { updateCrosshairsSynchronizer } from './lib/updateCrosshairsSynchronizer';
Studybase.updateCrosshairsSynchronizer = updateCrosshairsSynchronizer;

// getImageId
import { getImageId } from './lib/getImageId';
Studybase.getImageId = getImageId;

// setActiveViewport
import { setActiveViewport } from './lib/setActiveViewport';
Studybase.setActiveViewport = setActiveViewport;

// setFocusToActiveViewport
import { setFocusToActiveViewport } from './lib/setFocusToActiveViewport';
Studybase.setFocusToActiveViewport = setFocusToActiveViewport;

// getWADORSImageId
import { getWADORSImageId } from './lib/getWADORSImageId';
Studybase.getWADORSImageId = getWADORSImageId;

// updateAllViewports
import { updateAllViewports } from './lib/updateAllViewports';
Studybase.updateAllViewports = updateAllViewports;

// sortStudy
import { sortStudy } from './lib/sortStudy';
Studybase.sortStudy = sortStudy;

// updateMetaDataManager
import { updateMetaDataManager } from './lib/updateMetaDataManager';
Studybase.updateMetaDataManager = updateMetaDataManager;

// updateOrientationMarkers
import { updateOrientationMarkers } from './lib/updateOrientationMarkers';
Studybase.updateOrientationMarkers = updateOrientationMarkers;

// isImage
import { isImage } from './lib/isImage';
Studybase.isImage = isImage;

// getInstanceClassDefaultViewport, setInstanceClassDefaultViewportFunction
import { getInstanceClassDefaultViewport, setInstanceClassDefaultViewportFunction } from './lib/instanceClassSpecificViewport';
Studybase.getInstanceClassDefaultViewport = getInstanceClassDefaultViewport;
Studybase.setInstanceClassDefaultViewportFunction = setInstanceClassDefaultViewportFunction;

// displayReferenceLines
import { displayReferenceLines } from './lib/displayReferenceLines';
Studybase.displayReferenceLines = displayReferenceLines;

// getStudyMetadata
import { getStudyMetadata } from './lib/getStudyMetadata';
Studybase.getStudyMetadata = getStudyMetadata;

/**
 * Exported Namespaces (sub-namespaces)
 */

// imageViewerViewportData.*
import { imageViewerViewportData } from './lib/imageViewerViewportData';
Studybase.imageViewerViewportData = imageViewerViewportData;

// panelNavigation.*
import { panelNavigation } from './lib/panelNavigation';
Studybase.panelNavigation = panelNavigation;

// prepareViewerData
import { prepareViewerData } from './lib/prepareViewerData';
Studybase.prepareViewerData = prepareViewerData;

// renderViewer
import { renderViewer } from './lib/renderViewer';
Studybase.renderViewer = renderViewer;

// WLPresets.*
import { WLPresets } from './lib/WLPresets';
Studybase.wlPresets = WLPresets;

// hotkeyUtils.*
import { hotkeyUtils } from './lib/hotkeyUtils';
Studybase.hotkeyUtils = hotkeyUtils;

// viewportOverlayUtils.*
import { viewportOverlayUtils } from './lib/viewportOverlayUtils';
Studybase.viewportOverlayUtils = viewportOverlayUtils;

// viewportUtils.*
import { viewportUtils } from './lib/viewportUtils';
Studybase.viewportUtils = viewportUtils;

// thumbnailDragHandlers.*
import { thumbnailDragHandlers } from './lib/thumbnailDragHandlers';
Studybase.thumbnailDragHandlers = thumbnailDragHandlers;

// dialogUtils.*
import { dialogUtils } from './lib/dialogUtils';
Studybase.dialogUtils = dialogUtils;

// unloadHandlers.*
import { unloadHandlers } from './lib/unloadHandlers';
Studybase.unloadHandlers = unloadHandlers;

// sortingManager.*
import { sortingManager } from './lib/sortingManager';
Studybase.sortingManager = sortingManager;

// crosshairsSynchronizers.*
import { crosshairsSynchronizers } from './lib/crosshairsSynchronizers';
Studybase.crosshairsSynchronizers = crosshairsSynchronizers;

// annotateTextUtils.*
import { annotateTextUtils } from './lib/annotateTextUtils';
Studybase.annotateTextUtils = annotateTextUtils;

// textMarkerUtils.*
import { textMarkerUtils } from './lib/textMarkerUtils';
Studybase.textMarkerUtils = textMarkerUtils;

// createStacks.*
import { createStacks } from './lib/createStacks';
Studybase.createStacks = createStacks;


/**
 * Exported Singletons
 */

// StackManager as "stackManager" (since it's a plain object instance, the exported name starts with a lowercase letter)
import { StackManager } from './lib/StackManager';
Studybase.stackManager = StackManager;

// toolManager
import { toolManager } from './lib/toolManager';
Studybase.toolManager = toolManager;

/**
 * Exported Helpers
 */

import { helpers } from './lib/helpers/';
Studybase.helpers = helpers;

/**
 * Exported Collections
 */

// sopClassDictionary
import { sopClassDictionary } from './lib/sopClassDictionary';
Studybase.sopClassDictionary = sopClassDictionary;

// dicomTagDescriptions
import { DICOMTagDescriptions } from './lib/DICOMTagDescriptions';
Studybase.DICOMTagDescriptions = DICOMTagDescriptions;

/**
 * Exported Classes
 */

// ImageSet
import { ImageSet } from './lib/classes/ImageSet';
Studybase.ImageSet = ImageSet;

// LayoutManager
import { LayoutManager } from './lib/classes/LayoutManager';
Studybase.LayoutManager = LayoutManager;

// StudyPrefetcher
import { StudyPrefetcher } from './lib/classes/StudyPrefetcher';
Studybase.StudyPrefetcher = StudyPrefetcher;

// ResizeViewportManager
import { ResizeViewportManager } from './lib/classes/ResizeViewportManager';
Studybase.ResizeViewportManager = ResizeViewportManager;

// StudyLoadingListener
import { StudyLoadingListener } from './lib/classes/StudyLoadingListener';
Studybase.StudyLoadingListener = StudyLoadingListener;

// StackLoadingListener
import { StackLoadingListener } from './lib/classes/StudyLoadingListener';
Studybase.StackLoadingListener = StackLoadingListener;

// DICOMFileLoadingListener
import { DICOMFileLoadingListener } from './lib/classes/StudyLoadingListener';
Studybase.DICOMFileLoadingListener = DICOMFileLoadingListener;

// StudyMetadata, SeriesMetadata, InstanceMetadata
import { StudyMetadata } from './lib/classes/metadata/StudyMetadata';
import { SeriesMetadata } from './lib/classes/metadata/SeriesMetadata';
import { InstanceMetadata } from './lib/classes/metadata/InstanceMetadata';
import { StudySummary } from './lib/classes/metadata/StudySummary';
Studybase.metadata = { StudyMetadata, SeriesMetadata, InstanceMetadata, StudySummary };

// TypeSafeCollection
import { TypeSafeCollection } from './lib/classes/TypeSafeCollection';
Studybase.TypeSafeCollection = TypeSafeCollection;

// OHIFError
import { OHIFError } from './lib/classes/OHIFError';
Studybase.OHIFError = OHIFError;

// StackImagePositionOffsetSynchronizer
import { StackImagePositionOffsetSynchronizer } from './lib/classes/StackImagePositionOffsetSynchronizer';
Studybase.StackImagePositionOffsetSynchronizer = StackImagePositionOffsetSynchronizer;

// StudyMetadataSource
import { StudyMetadataSource } from './lib/classes/StudyMetadataSource';
Studybase.StudyMetadataSource = StudyMetadataSource;
