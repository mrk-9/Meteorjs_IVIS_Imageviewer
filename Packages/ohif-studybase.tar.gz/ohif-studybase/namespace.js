/**
 * Import main dependency
 */

import { OHIF } from 'meteor/ohif:core';

/**
 * Create Studybase namespace
 */

const Studybase = {};

/**
 * Append Studybase namespace to OHIF namespace
 */

OHIF.studybase = Studybase;

/**
 * Export relevant objects
 */

export { OHIF, Studybase };
